import React from 'react'

export default function Legacy() {
  return (
    <div>Legacy</div>
  )
}
