import React from 'react'

function UserDetails() {
  return (
    <div>UserDetails</div>
  )
}

export default UserDetails